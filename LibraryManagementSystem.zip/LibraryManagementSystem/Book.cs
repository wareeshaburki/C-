using System;
using System.Reflection;

namespace LibraryManagementSystem;

public class Book
{
    public int bookId;
    public string bookTitle;
    public string author;
    public int availableCopies;
}