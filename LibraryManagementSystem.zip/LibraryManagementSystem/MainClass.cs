using System;

namespace LibraryManagementSystem;

public class MainClass
{
    static Library library = new Library();
    public static void Main()
    {
        Console.WriteLine();
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine("==========================================");
        Console.WriteLine("   WELCOME TO LIBRARY MANAGEMENT SYSTEM   ");
        Console.WriteLine("==========================================");
        Console.ResetColor();
        Console.WriteLine();

        string? option;

        do
        {
            DisplayMenu();
            Console.Write("Choose any one option: ");
            option = Console.ReadLine();
            switch (option)
            {
                case "1":
                    Console.WriteLine();
                    Console.WriteLine("Add a Book");
                    Console.WriteLine();
                    library.AddBook();
                    Console.WriteLine();
                    break;
                case "2":
                    Console.WriteLine();
                    Console.WriteLine("Add Members");
                    Console.WriteLine();
                    library.AddMember();
                    Console.WriteLine();
                    break;
                case "3":
                    Console.WriteLine();
                    Console.WriteLine("View All Books");
                    Console.WriteLine();
                    library.ViewBook();
                    Console.WriteLine();
                    break;
                case "4":
                    Console.WriteLine();
                    Console.WriteLine("View All Members");
                    Console.WriteLine();
                    library.ViewMembers();
                    Console.WriteLine();
                    break;
                case "5":
                    Console.WriteLine();
                    Console.WriteLine("Borrow a Book");
                    Console.WriteLine();
                    library.BorrowBook();
                    Console.WriteLine();
                    break;
                case "6":
                    Console.WriteLine();
                    Console.WriteLine("Return a Book");
                    Console.WriteLine();
                    library.ReturnBook();
                    Console.WriteLine();
                    break;
                case "7":
                    Console.WriteLine();
                    Console.WriteLine("Search a Book");
                    Console.WriteLine();
                    library.SearchBook();
                    Console.WriteLine();
                    break;
                case "8":
                    Console.WriteLine();
                    break;
            }
            Console.WriteLine("Enter \"Exit\" to end the program");
            option = Console.ReadLine();
        } while (option.ToLower() != "exit");
    }

    public static void DisplayMenu()
    {
        Console.WriteLine();
        Console.WriteLine("1. Add Book");
        Console.WriteLine("2. Add Member");
        Console.WriteLine("3. View Books");
        Console.WriteLine("4. View Member");
        Console.WriteLine("5. Borrow Book");
        Console.WriteLine("6. Return Book");
        Console.WriteLine("7. Search Book");
        Console.WriteLine("8. Exit");
        Console.WriteLine();
    }
}