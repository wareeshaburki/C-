using System;

namespace LibraryManagementSystem;

public class Member
{
    public int memberId;
    public string memberName;
    public List<int> borrowedBooks = new List<int>();
}