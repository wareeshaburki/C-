using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.IO;

namespace LibraryManagementSystem;

public class Library
{
    private List<Book> books = new List<Book>();
    private List<Member> members = new List<Member>();

    public Library()
    {
        LoadData();
    }

    private void SaveData()
    {
        File.WriteAllText("books.json", JsonSerializer.Serialize(books, new JsonSerializerOptions { WriteIndented = true }));
        File.WriteAllText("members.json", JsonSerializer.Serialize(members, new JsonSerializerOptions { WriteIndented = true }));
    }
    private void LoadData()
    {
        if (File.Exists("books.json"))
        {
            string booksJson = File.ReadAllText("books.json");
            books = JsonSerializer.Deserialize<List<Book>>(booksJson) ?? new List<Book>();
        }
        if (File.Exists("members.json"))
        {
            string membersJson = File.ReadAllText("members.json");
            members = JsonSerializer.Deserialize<List<Member>>(membersJson) ?? new List<Member>();
        }
    }
    public void AddBook()
    {
        string? option;
        Console.Write("Enter \"back\" to go back aur enter anything to continue: ");
        option = Console.ReadLine();

        while (true)
        {
            if (option.ToLower() == "back")
            {
                return;
            }

            Console.WriteLine("Enter Book Details to enter");
            Console.WriteLine();
            Console.Write("Enter Book ID : ");

            if (!int.TryParse(Console.ReadLine(), out int id))
            {
                Console.WriteLine("Invalid input! Please enter a number.");
                return;
            }


            if (books.Any(b => b.bookId == id))
            {
                Console.WriteLine("A book with this ID already exists.");
                return;
            }

            Console.Write("Enter Book Title : ");
            string title = Console.ReadLine();
            Console.Write("Enter Book Author Name : ");
            string bookAuthor = Console.ReadLine();
            Console.Write("Enter Book Available Copies : ");
            int bookAvailableCopies = int.Parse(Console.ReadLine());

            if (books.Any(b => b.bookTitle != null && b.bookTitle.Equals(title, StringComparison.OrdinalIgnoreCase)
                               && b.author!=null && b.author.Equals(bookAuthor, StringComparison.OrdinalIgnoreCase)))
            {
                Console.WriteLine("This book already exists in the library.");
                return;
            }

            books.Add(new Book { bookId = id, bookTitle = title, author = bookAuthor, availableCopies = bookAvailableCopies });
            Console.WriteLine();
            Console.WriteLine("Book added Successfully");
            Console.WriteLine();
            SaveData();
            Console.Write("Enter \"back\" to go back aur enter anything to continue adding books: ");
            option = Console.ReadLine();
        }
    }
    public void AddMember()
    {
        string? option;
        Console.Write("Enter \"back\" to go back aur enter anything to continue: ");
        option = Console.ReadLine();
        while (true)
        {
            if (option.ToLower() == "back")
            {
                return;
            }

            Console.WriteLine("Enter Member Details to enter");
            Console.WriteLine();
            Console.Write("Enter Member ID : ");
            
            if (!int.TryParse(Console.ReadLine(), out int id))
            {
                Console.WriteLine("Invalid input! Please enter a number.");
                return;
            }

            if (members.Any(m => m.memberId == id))
            {
                Console.WriteLine("A member with this ID already exists. Please try again.");
                return;
            }

            Console.Write("Enter Member Name : ");
            string name = Console.ReadLine();

            if (members.Any(m => m.memberName!=null && m.memberName.Equals(name, StringComparison.OrdinalIgnoreCase)))
            {
                Console.WriteLine("A member with this name already exists.");
                return;
            }

            members.Add(new Member { memberId = id, memberName = name });
            Console.WriteLine();
            Console.WriteLine("Member added Successfully");
            Console.WriteLine();
            SaveData();
            Console.Write("Enter \"back\" to go back aur enter anything to continue adding members: ");
            option = Console.ReadLine();
        }
    }

    public void ViewBook()
    {
        if (!books.Any())
        {
            Console.WriteLine("No Books Found");
            return;
        }
        Console.WriteLine("Books In Library: ");
        Console.WriteLine();
        foreach (var book in books)
        {
            Console.WriteLine($"Book ID: {book.bookId} \nBook Title: {book.bookTitle} \nBook Author Name: {book.author} \nBook Available Copies: {book.availableCopies}");
            Console.WriteLine();
        }
    }
    public void ViewMembers()
    {
        if (!members.Any())
        {
            Console.WriteLine("No Members Found");
            return;
        }
        Console.WriteLine("Members In Library: ");
        Console.WriteLine();
        foreach (var member in members)
        {
            Console.WriteLine($"Member ID: {member.memberId} \nMember Name: {member.memberName}");
            Console.WriteLine();
        }
    }
    public void SearchBook()
    {
        Console.Write("Enter Book Title to search: ");
        string bookTitle = Console.ReadLine();
        Book book = books.FirstOrDefault(b => b.bookTitle.Contains(bookTitle, StringComparison.OrdinalIgnoreCase));
        if (book == null)
        {
            Console.WriteLine("Book not Found");
            return;
        }
        Console.WriteLine("Book found");
        Console.WriteLine($"Book Id: {book.bookId}");
        Console.WriteLine($"Book Title : {book.bookTitle}");
        Console.WriteLine($"Book Author: {book.author}");
        Console.WriteLine($"Book Available Copies : {book.availableCopies}");

    }
    public void BorrowBook()
    {
        Console.Write("Enter your member ID: ");
        int memberId = int.Parse(Console.ReadLine());
        Member member = members.FirstOrDefault(m => m.memberId == memberId);
        if (member == null)
        {
            Console.WriteLine("Member not found");
            return;
        }
        Console.Write("Enter ID of the book you want to borrow: ");
        int bookId = int.Parse(Console.ReadLine());
        Book book = books.FirstOrDefault(b => b.bookId == bookId);
        if (book == null)
        {
            Console.WriteLine("Book not found");
            return;
        }
        Console.WriteLine($"Book : {book.bookTitle}");
        Console.WriteLine($"Member : {member.memberName}");
        if (member.borrowedBooks.Contains(bookId))
        {
            Console.WriteLine("Member has already borrowed a copy of this book");
            return;
        }
        if (book.availableCopies > 0)
        {
            book.availableCopies--;
            member.borrowedBooks.Add(bookId);
            Console.WriteLine("Book borrowed successfully");
            SaveData();
            return;
        }
        else
        {
            Console.WriteLine("Copies of this book are not available right now");
            return;
        }
    }

    public void ReturnBook()
    {
        Console.Write("Enter your member ID: ");
        int memberId = int.Parse(Console.ReadLine());
        Member member = members.FirstOrDefault(m => m.memberId == memberId);
        if (member == null)
        {
            Console.WriteLine("Member not found");
            return;
        }
        Console.Write("Enter ID of the book you want to return: ");
        int bookId = int.Parse(Console.ReadLine());
        Book book = books.FirstOrDefault(b => b.bookId == bookId);
        if (book == null)
        {
            Console.WriteLine("Book not found");
            return;
        }
        Console.WriteLine($"Book : {book.bookTitle}");
        Console.WriteLine($"Member : {member.memberName}");
        if (!member.borrowedBooks.Contains(bookId))
        {
            Console.WriteLine("This member hasn't borrowed any copy to return");
            return;
        }
        book.availableCopies++;
        member.borrowedBooks.Remove(bookId);
        Console.WriteLine("Book returned successfully");
        SaveData();
    }
}
