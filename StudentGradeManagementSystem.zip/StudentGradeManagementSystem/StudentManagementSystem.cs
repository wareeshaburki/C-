// using System;

// public class StudentManagementSystem
// {
//     static Dictionary<string, string?[]> students = new Dictionary<string, string?[]>();
//     public static void Main()
//     {
//         string? option;
//         Console.WriteLine();
//         Console.ForegroundColor = ConsoleColor.Cyan;
//         Console.WriteLine("-------------------------------------------------");
//         Console.WriteLine();
//         Console.WriteLine("    WELCOME TO STUDENT GRADE MANAGEMENT SYSTEM    ");
//         Console.WriteLine();
//         Console.WriteLine("-------------------------------------------------");
//         Console.ResetColor();
//         do
//         {
//             Console.WriteLine();
//             DisplayMenu();
//             option = Console.ReadLine();
//             Console.WriteLine();
//             switch (option)
//             {
//                 case "1":
//                     Console.ForegroundColor = ConsoleColor.Cyan;
//                     Console.WriteLine("Add a Student");
//                     Console.ResetColor();
//                     Console.WriteLine();
//                     AddStudent();
//                     break;
//                 case "2":
//                     Console.ForegroundColor = ConsoleColor.Cyan;
//                     Console.WriteLine("View All Students ");
//                     Console.ResetColor();
//                     Console.WriteLine();
//                     ViewStudent();
//                     break;
//                 case "3":
//                     Console.ForegroundColor = ConsoleColor.Cyan;
//                     Console.WriteLine("Search a Student ");
//                     Console.ResetColor();
//                     Console.WriteLine();
//                     SearchStudent();
//                     break;

//             }
//         } while (option != "exit");
//     }

//     public static void DisplayMenu()
//     {
//         Console.WriteLine();
//         Console.WriteLine("Choose an option:");
//         Console.WriteLine("1. Enter 1 to Add Student");
//         Console.WriteLine("2. Enter 2 to View All Students");
//         Console.WriteLine("3. Enter 3 to Search Student");
//         Console.WriteLine("4. Enter \"exit\" to leave");
//     }

//     public static void AddStudent()
//     {
//         string? studentName;
//         string?[] studentGrades = new string[3];
//         string? option;
//         do
//         {
//             Console.Write("Enter Student Name: ");
//             studentName = Console.ReadLine();
//             Console.Write("Enter Student Grades: ");
//             for (int i = 0; i < studentGrades.Length; i++)
//             {
//                 studentGrades[i] = Console.ReadLine();
//             }
//             if (string.IsNullOrWhiteSpace(studentName))
//             {
//                 Console.WriteLine("⚠️ Student name cannot be empty!");
//             }
//             else if (students.ContainsKey(studentName))
//             {
//                 Console.WriteLine("⚠️ A student with this name already exists.");
//             }
//             else
//             {
//                 students[studentName] = studentGrades;
//                 Console.WriteLine("✅ Student added successfully!");
//             }
//             Console.WriteLine("If you want to go back enter \"back\"");
//             option = Console.ReadLine();
//         } while (option != "back");
//     }

//     public static void ViewStudent()
//     {
//         if (students.Count == 0)
//         {
//             Console.WriteLine("No Students Available");
//             return;
//         }
//         foreach (var student in students)
//         {
//             Console.WriteLine($"Student: {student.Key}");
//             Console.WriteLine("Grades: ");
//             foreach (var grade in student.Value)
//             {
//                 Console.WriteLine($"--{grade}");
//             }
//             Console.WriteLine("------------------------------------");
//         }
//     }

//     public static void SearchStudent()
//     {
//         string? option;
//         string? studentName;
//         do
//         {
//             Console.WriteLine("Enter Student name to search : ");
//             studentName = Console.ReadLine();
//             if (studentName == null)
//             {
//                 Console.WriteLine("Must enter a Student Name to search: ");
//             }
//             else if (students.ContainsKey(studentName))
//             {
//                 Console.WriteLine($"Student: {studentName}");
//                 Console.WriteLine("Grades: ");
//                 foreach (var grade in students[studentName])
//                 {
//                     Console.WriteLine("  " + grade);
//                 }
//             }
//             else
//             {
//                 Console.WriteLine("Student doesn't exist");
//             }
//             Console.Write("Enter \"back\" to return: ");
//             option = Console.ReadLine();
//         } while (option != "back");
//     }
// }
